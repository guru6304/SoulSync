const dashboardRepository = require('../repositories/dashboard.repository');
const coupleService = require('./couple.service');

class DashboardService {

    async getDashboard(userId) {

        const user =
            await dashboardRepository.findUser(userId);

        const membership = user.couples
            ? user.couples[0]
            : null;

        if (!membership) {
            return {
                user,
                partner: null,
                todayMood: null,
                recentMemories: [],
                pendingInvitation: null,
            };
        }

        const coupleId = membership.id;

        await coupleService.findMembership(
            userId,
            coupleId
        );

        const today = new Date()
            .toISOString()
            .split('T')[0];

        const [
            partner,
            todayMood,
            recentMemories,
            pendingInvitation,
        ] = await Promise.all([
            coupleService.getPartner(
                userId,
                coupleId
            ),
            dashboardRepository.findTodayMood(
                userId,
                today
            ),
            dashboardRepository.findRecentMemories(
                coupleId
            ),
            dashboardRepository.findPendingInvitation(
                userId
            ),
        ]);

        return {
            user,
            partner,
            todayMood,
            recentMemories,
            pendingInvitation,
        };
    }

    async getStats(userId) {

        const user =
            await dashboardRepository.findUser(userId);

        const coupleId =
            user.couples[0].id;

        const [
            memoryCount,
            photoCount,
            videoCount,
            questionAnswered,
        ] = await Promise.all([
            dashboardRepository.getMemoryCount(
                coupleId
            ),
            dashboardRepository.getMediaCount(
                coupleId,
                'image'
            ),
            dashboardRepository.getMediaCount(
                coupleId,
                'video'
            ),
            dashboardRepository.getAnswerCount(
                coupleId
            ),
        ]);

        return {
            memoryCount,
            photoCount,
            videoCount,
            questionAnswered,
        };
    }

    async getActivity(userId) {

        const user =
            await dashboardRepository.findUser(userId);

        const coupleId =
            user.couples[0].id;

        const [
            memories,
            answers,
            moods,
        ] = await Promise.all([
            dashboardRepository.findRecentMemories(
                coupleId
            ),
            dashboardRepository.getRecentAnswers(
                coupleId
            ),
            dashboardRepository.getRecentMoodActivities(
                coupleId
            ),
        ]);

        return {
            memories,
            answers,
            moods,
        };
    }
}

module.exports = new DashboardService();