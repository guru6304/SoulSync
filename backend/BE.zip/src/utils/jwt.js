const jwt = require('jsonwebtoken');

const generateAccessToken = (payload) => jwt.sign(payload, process.env.JWT_ACCESS_SECRET, {
  expiresIn: process.env.JWT_ACCESS_EXPIRES_IN,
  algorithm: 'HS256',
});

const generateRefreshToken = (payload) => jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
  expiresIn: process.env.JWT_REFRESH_EXPIRES_IN,
  algorithm: 'HS256',
});

const verifyAccessToken = (token) => jwt.verify(token, process.env.JWT_ACCESS_SECRET);

const verifyRefreshToken = (token) => jwt.verify(token, process.env.JWT_REFRESH_SECRET);

module.exports = {
  generateAccessToken,
  generateRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
};
